import React from 'react';
import Bookingform from './bookingform';
export default function Bookingroom() {
    return (
        <div className="banner-section">      
            <div className="inner-banner">      
                <div className='container'>
                    <div className="row">
                        <Bookingform/>
                    </div>
                </div>
            </div>
        </div>
    )
}
