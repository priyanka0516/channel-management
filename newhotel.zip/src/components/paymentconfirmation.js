import React from 'react'
export default function Paymentonfirmation() {
  return (
    <div className=''>
      <div className='container'>
        <div className='row'>
          <div className='col-md-6'>
            <p>fgfgfg</p>
          </div>
          <div className='col-md-6'>
            <p>fghfhghg</p>
            <h1></h1>
          </div>
        </div>
      </div>
    </div>
  )
}
